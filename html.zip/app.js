var express = require('express');
var app = express();

// EJS를 사용하도록 Express에 설정합니다.
app.set('view engine', 'ejs');

// 라우트를 설정합니다.
app.get('/', function(req, res) {
    const data = {
        title: "home"
    };
    res.render('index', data);
});

// 서버를 시작합니다.
var server = app.listen(3000, function() {
    console.log('Server listening on port 3000');
});