//navbar active
if (window.location.pathname == '/') {
    $("#home").addClass("active");
} else if (window.location.pathname == '/about') {
    $("#about").addClass("active");
} else if (window.location.pathname == '/login') {
    $("#login").addClass("active");
};

//darkmode inverse
if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {$("#nav").addClass("navbar-inverse")};